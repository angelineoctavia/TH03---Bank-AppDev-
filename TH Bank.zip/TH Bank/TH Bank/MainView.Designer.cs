﻿namespace TH_Bank
{
    partial class MainViewcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_UCBank_MainView = new System.Windows.Forms.Label();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.lbl_Balance = new System.Windows.Forms.Label();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.btn_Withdraw = new System.Windows.Forms.Button();
            this.lbl_Rp = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_UCBank_MainView
            // 
            this.lbl_UCBank_MainView.AutoSize = true;
            this.lbl_UCBank_MainView.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank_MainView.Location = new System.Drawing.Point(165, 63);
            this.lbl_UCBank_MainView.Name = "lbl_UCBank_MainView";
            this.lbl_UCBank_MainView.Size = new System.Drawing.Size(224, 55);
            this.lbl_UCBank_MainView.TabIndex = 3;
            this.lbl_UCBank_MainView.Text = "UC Bank";
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(382, 121);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(154, 44);
            this.btn_LogOut.TabIndex = 4;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            // 
            // lbl_Balance
            // 
            this.lbl_Balance.AutoSize = true;
            this.lbl_Balance.Location = new System.Drawing.Point(170, 225);
            this.lbl_Balance.Name = "lbl_Balance";
            this.lbl_Balance.Size = new System.Drawing.Size(90, 25);
            this.lbl_Balance.TabIndex = 5;
            this.lbl_Balance.Text = "Balance";
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(273, 279);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(154, 44);
            this.btn_Deposit.TabIndex = 6;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // btn_Withdraw
            // 
            this.btn_Withdraw.Location = new System.Drawing.Point(273, 340);
            this.btn_Withdraw.Name = "btn_Withdraw";
            this.btn_Withdraw.Size = new System.Drawing.Size(154, 44);
            this.btn_Withdraw.TabIndex = 7;
            this.btn_Withdraw.Text = "Withdraw";
            this.btn_Withdraw.UseVisualStyleBackColor = true;
            // 
            // lbl_Rp
            // 
            this.lbl_Rp.AutoSize = true;
            this.lbl_Rp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Rp.Location = new System.Drawing.Point(266, 210);
            this.lbl_Rp.Name = "lbl_Rp";
            this.lbl_Rp.Size = new System.Drawing.Size(156, 42);
            this.lbl_Rp.TabIndex = 8;
            this.lbl_Rp.Text = "Rp 0,00";
            // 
            // MainViewcs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl_Rp);
            this.Controls.Add(this.btn_Withdraw);
            this.Controls.Add(this.btn_Deposit);
            this.Controls.Add(this.lbl_Balance);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.lbl_UCBank_MainView);
            this.Name = "MainViewcs";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_UCBank_MainView;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Label lbl_Balance;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Button btn_Withdraw;
        private System.Windows.Forms.Label lbl_Rp;
    }
}