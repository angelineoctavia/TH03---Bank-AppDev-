﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Bank
{
    public partial class Form1 : Form
    {
        private List<string> InputUsername = new List<string>();
        private List<string> InputPassword = new List<string>();
        private List<int> Balance = new List<int>();
        int indexAkun;
        string Rupiah;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Register_LoginView_Click(object sender, EventArgs e)
        {
            panel_LoginView.Visible = false;
            panel_RegisterView.Visible = true;
            panel_Deposit.Visible = false;
        }

        private void btn_Register_RegisterView_Click(object sender, EventArgs e)
        {
            string input = tBox_Username_RegisterView.Text;
            string password = tBox_Password_RegisterView.Text;

            if (InputUsername.Contains(input))
            {
                MessageBox.Show("Username has been used");
            }
            else
            {
                InputUsername.Add(input);
                InputPassword.Add(password);
                Balance.Add(0);
                MessageBox.Show("Register Successful");
                panel_RegisterView.Visible = false;
                panel_LoginView.Visible = true;
            }
            tBox_Username_RegisterView.Clear();
            tBox_Password_RegisterView.Clear();
        }

        private bool ngecek_password_username (string input, string password)
        {
            for (int i = 0; i < InputUsername.Count; i++)
            {
                if (InputUsername[i] == input && InputPassword[i] == password) 
                {
                    indexAkun = i;
                    return true;
                }
            }
            return false;
        }

        private void btn_Login_LoginView_Click(object sender, EventArgs e)
        {
            string inputUsername = tBox_Username_LoginView.Text;
            string inputPassword = tBox_Password_LoginView.Text;

            if (ngecek_password_username(inputUsername, inputPassword) == true)
            {
                MessageBox.Show("Login Successful");
                panel_LoginView.Visible = false;
                panel_RegisterView.Visible = false;
                panel_MainView.Visible = true;
                panel_Deposit.Visible = false;
                indexAkun = InputUsername.IndexOf(inputUsername);
            }
            else
            {
                MessageBox.Show("Username and Password not Found!");
            }
            tBox_Username_LoginView.Clear();
            tBox_Password_LoginView.Clear();
        }

        private void btn_Deposit_MainView_Click(object sender, EventArgs e)
        {
            panel_MainView.Visible = true;
            panel_Deposit.Visible = true;
        }

        private void btn_Deposit_DepositView_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tBox_JumlahDeposit.Text) <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
            else if (Convert.ToInt32(tBox_JumlahDeposit.Text) > 0) 
            {
                int intDeposit = Convert.ToInt32(tBox_JumlahDeposit.Text);
                Balance[indexAkun] = Balance[indexAkun] + intDeposit;
                MessageBox.Show("Successfully Add Deposit");
                lbl_Rp.Text = UbahRupiah(Balance[indexAkun]);
                lbl_Rupiah_WithdrawalView.Text = UbahRupiah(Balance[indexAkun]);
            }
            tBox_JumlahDeposit.Clear();
            panel_Deposit.Visible = false;
        }

        private void panel_MainView_VisibleChanged(object sender, EventArgs e)
        {
            lbl_Rp.Text = UbahRupiah(Balance[indexAkun]);
            lbl_Rupiah_WithdrawalView.Text = UbahRupiah(Balance[indexAkun]);
        }

        public string UbahRupiah(int Balance)
        {
            Rupiah = string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "{0:C2}", Balance);
            return Rupiah;
        }

        private void btn_Withdraw_MainView_Click(object sender, EventArgs e)
        {
            panel_WithdrawalView.Visible = true;
        }

        private void btn_Witdraw_WithdrawView_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(tBox_JumlahWithdrawal.Text) > Balance[indexAkun])
            {
                MessageBox.Show("Withdraw Failed. Not Enough Balance.");
            }
            else if (Convert.ToInt32(tBox_JumlahWithdrawal.Text) <= 0)
            {
                MessageBox.Show("Withdraw Amount Can't be less than 1");
            }
            else
            {
                int intDeposit = Convert.ToInt32(tBox_JumlahWithdrawal.Text);
                Balance[indexAkun] = Balance[indexAkun] - intDeposit;
                MessageBox.Show("Successfully Withdraw");
                lbl_Rp.Text = UbahRupiah(Balance[indexAkun]);
                lbl_Rupiah_WithdrawalView.Text = UbahRupiah(Balance[indexAkun]);
            }
            tBox_JumlahWithdrawal.Clear();
            panel_WithdrawalView.Visible = false;
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            panel_MainView.Visible = false;
            panel_LoginView.Visible = true;
        }
    }
}
