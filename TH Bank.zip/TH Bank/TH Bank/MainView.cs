﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_Bank
{
    public partial class MainViewcs : Form
    {
        public MainViewcs()
        {
            InitializeComponent();
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            btn_Withdraw.Visible = false;
            lbl_Balance.Visible = false;
            lbl_Rp.Visible = false;
        }
    }
}
