﻿namespace TH_Bank
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tBox_Username_LoginView = new System.Windows.Forms.TextBox();
            this.tBox_Password_LoginView = new System.Windows.Forms.TextBox();
            this.lbl_UCBank = new System.Windows.Forms.Label();
            this.lbl_Username_LoginView = new System.Windows.Forms.Label();
            this.lbl_Password_LoginView = new System.Windows.Forms.Label();
            this.btn_Register_LoginView = new System.Windows.Forms.Button();
            this.btn_Login_LoginView = new System.Windows.Forms.Button();
            this.tBox_Password_RegisterView = new System.Windows.Forms.TextBox();
            this.tBox_Username_RegisterView = new System.Windows.Forms.TextBox();
            this.btn_Register_RegisterView = new System.Windows.Forms.Button();
            this.lbl_Password_RegisterView = new System.Windows.Forms.Label();
            this.lbl_Username_RegisterView = new System.Windows.Forms.Label();
            this.lbl_UCBank_RegisterView = new System.Windows.Forms.Label();
            this.panel_LoginView = new System.Windows.Forms.Panel();
            this.panel_RegisterView = new System.Windows.Forms.Panel();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.lbl_UCBank_MainView = new System.Windows.Forms.Label();
            this.panel_MainView = new System.Windows.Forms.Panel();
            this.btn_Deposit_DepositView = new System.Windows.Forms.Button();
            this.lbl_InputDepositAmount = new System.Windows.Forms.Label();
            this.panel_Deposit = new System.Windows.Forms.Panel();
            this.tBox_JumlahDeposit = new System.Windows.Forms.TextBox();
            this.tBox_JumlahWithdrawal = new System.Windows.Forms.TextBox();
            this.btn_Witdraw_WithdrawView = new System.Windows.Forms.Button();
            this.lbl_InputWithdrawal = new System.Windows.Forms.Label();
            this.lbl_Rupiah_WithdrawalView = new System.Windows.Forms.Label();
            this.lbl_Balance_WithdrawalView = new System.Windows.Forms.Label();
            this.panel_WithdrawalView = new System.Windows.Forms.Panel();
            this.lbl_Rp = new System.Windows.Forms.Label();
            this.btn_Withdraw_MainView = new System.Windows.Forms.Button();
            this.btn_Deposit_MainView = new System.Windows.Forms.Button();
            this.lbl_Balance_MainView = new System.Windows.Forms.Label();
            this.panel_LoginView.SuspendLayout();
            this.panel_RegisterView.SuspendLayout();
            this.panel_MainView.SuspendLayout();
            this.panel_Deposit.SuspendLayout();
            this.panel_WithdrawalView.SuspendLayout();
            this.SuspendLayout();
            // 
            // tBox_Username_LoginView
            // 
            this.tBox_Username_LoginView.Location = new System.Drawing.Point(183, 95);
            this.tBox_Username_LoginView.Name = "tBox_Username_LoginView";
            this.tBox_Username_LoginView.Size = new System.Drawing.Size(189, 31);
            this.tBox_Username_LoginView.TabIndex = 0;
            // 
            // tBox_Password_LoginView
            // 
            this.tBox_Password_LoginView.Location = new System.Drawing.Point(183, 160);
            this.tBox_Password_LoginView.Name = "tBox_Password_LoginView";
            this.tBox_Password_LoginView.Size = new System.Drawing.Size(189, 31);
            this.tBox_Password_LoginView.TabIndex = 1;
            // 
            // lbl_UCBank
            // 
            this.lbl_UCBank.AutoSize = true;
            this.lbl_UCBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank.Location = new System.Drawing.Point(56, 1);
            this.lbl_UCBank.Name = "lbl_UCBank";
            this.lbl_UCBank.Size = new System.Drawing.Size(224, 55);
            this.lbl_UCBank.TabIndex = 2;
            this.lbl_UCBank.Text = "UC Bank";
            // 
            // lbl_Username_LoginView
            // 
            this.lbl_Username_LoginView.AutoSize = true;
            this.lbl_Username_LoginView.Location = new System.Drawing.Point(61, 95);
            this.lbl_Username_LoginView.Name = "lbl_Username_LoginView";
            this.lbl_Username_LoginView.Size = new System.Drawing.Size(116, 25);
            this.lbl_Username_LoginView.TabIndex = 3;
            this.lbl_Username_LoginView.Text = "Username:";
            // 
            // lbl_Password_LoginView
            // 
            this.lbl_Password_LoginView.AutoSize = true;
            this.lbl_Password_LoginView.Location = new System.Drawing.Point(61, 163);
            this.lbl_Password_LoginView.Name = "lbl_Password_LoginView";
            this.lbl_Password_LoginView.Size = new System.Drawing.Size(112, 25);
            this.lbl_Password_LoginView.TabIndex = 4;
            this.lbl_Password_LoginView.Text = "Password:";
            // 
            // btn_Register_LoginView
            // 
            this.btn_Register_LoginView.Location = new System.Drawing.Point(183, 293);
            this.btn_Register_LoginView.Name = "btn_Register_LoginView";
            this.btn_Register_LoginView.Size = new System.Drawing.Size(164, 48);
            this.btn_Register_LoginView.TabIndex = 6;
            this.btn_Register_LoginView.Text = "Register";
            this.btn_Register_LoginView.UseVisualStyleBackColor = true;
            this.btn_Register_LoginView.Click += new System.EventHandler(this.btn_Register_LoginView_Click);
            // 
            // btn_Login_LoginView
            // 
            this.btn_Login_LoginView.Location = new System.Drawing.Point(183, 228);
            this.btn_Login_LoginView.Name = "btn_Login_LoginView";
            this.btn_Login_LoginView.Size = new System.Drawing.Size(164, 48);
            this.btn_Login_LoginView.TabIndex = 8;
            this.btn_Login_LoginView.Text = "Login";
            this.btn_Login_LoginView.UseVisualStyleBackColor = true;
            this.btn_Login_LoginView.Click += new System.EventHandler(this.btn_Login_LoginView_Click);
            // 
            // tBox_Password_RegisterView
            // 
            this.tBox_Password_RegisterView.Location = new System.Drawing.Point(186, 186);
            this.tBox_Password_RegisterView.Name = "tBox_Password_RegisterView";
            this.tBox_Password_RegisterView.Size = new System.Drawing.Size(189, 31);
            this.tBox_Password_RegisterView.TabIndex = 20;
            // 
            // tBox_Username_RegisterView
            // 
            this.tBox_Username_RegisterView.Location = new System.Drawing.Point(186, 121);
            this.tBox_Username_RegisterView.Name = "tBox_Username_RegisterView";
            this.tBox_Username_RegisterView.Size = new System.Drawing.Size(189, 31);
            this.tBox_Username_RegisterView.TabIndex = 19;
            // 
            // btn_Register_RegisterView
            // 
            this.btn_Register_RegisterView.Location = new System.Drawing.Point(186, 253);
            this.btn_Register_RegisterView.Name = "btn_Register_RegisterView";
            this.btn_Register_RegisterView.Size = new System.Drawing.Size(164, 48);
            this.btn_Register_RegisterView.TabIndex = 17;
            this.btn_Register_RegisterView.Text = "Register";
            this.btn_Register_RegisterView.UseVisualStyleBackColor = true;
            this.btn_Register_RegisterView.Click += new System.EventHandler(this.btn_Register_RegisterView_Click);
            // 
            // lbl_Password_RegisterView
            // 
            this.lbl_Password_RegisterView.AutoSize = true;
            this.lbl_Password_RegisterView.Location = new System.Drawing.Point(64, 192);
            this.lbl_Password_RegisterView.Name = "lbl_Password_RegisterView";
            this.lbl_Password_RegisterView.Size = new System.Drawing.Size(112, 25);
            this.lbl_Password_RegisterView.TabIndex = 15;
            this.lbl_Password_RegisterView.Text = "Password:";
            // 
            // lbl_Username_RegisterView
            // 
            this.lbl_Username_RegisterView.AutoSize = true;
            this.lbl_Username_RegisterView.Location = new System.Drawing.Point(64, 124);
            this.lbl_Username_RegisterView.Name = "lbl_Username_RegisterView";
            this.lbl_Username_RegisterView.Size = new System.Drawing.Size(116, 25);
            this.lbl_Username_RegisterView.TabIndex = 14;
            this.lbl_Username_RegisterView.Text = "Username:";
            // 
            // lbl_UCBank_RegisterView
            // 
            this.lbl_UCBank_RegisterView.AutoSize = true;
            this.lbl_UCBank_RegisterView.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank_RegisterView.Location = new System.Drawing.Point(59, 30);
            this.lbl_UCBank_RegisterView.Name = "lbl_UCBank_RegisterView";
            this.lbl_UCBank_RegisterView.Size = new System.Drawing.Size(224, 55);
            this.lbl_UCBank_RegisterView.TabIndex = 13;
            this.lbl_UCBank_RegisterView.Text = "UC Bank";
            // 
            // panel_LoginView
            // 
            this.panel_LoginView.Controls.Add(this.btn_Login_LoginView);
            this.panel_LoginView.Controls.Add(this.btn_Register_LoginView);
            this.panel_LoginView.Controls.Add(this.lbl_Password_LoginView);
            this.panel_LoginView.Controls.Add(this.lbl_Username_LoginView);
            this.panel_LoginView.Controls.Add(this.lbl_UCBank);
            this.panel_LoginView.Controls.Add(this.tBox_Password_LoginView);
            this.panel_LoginView.Controls.Add(this.tBox_Username_LoginView);
            this.panel_LoginView.Location = new System.Drawing.Point(125, 57);
            this.panel_LoginView.Name = "panel_LoginView";
            this.panel_LoginView.Size = new System.Drawing.Size(452, 354);
            this.panel_LoginView.TabIndex = 21;
            // 
            // panel_RegisterView
            // 
            this.panel_RegisterView.Controls.Add(this.tBox_Password_RegisterView);
            this.panel_RegisterView.Controls.Add(this.tBox_Username_RegisterView);
            this.panel_RegisterView.Controls.Add(this.btn_Register_RegisterView);
            this.panel_RegisterView.Controls.Add(this.lbl_Password_RegisterView);
            this.panel_RegisterView.Controls.Add(this.lbl_Username_RegisterView);
            this.panel_RegisterView.Controls.Add(this.lbl_UCBank_RegisterView);
            this.panel_RegisterView.Location = new System.Drawing.Point(128, 51);
            this.panel_RegisterView.Name = "panel_RegisterView";
            this.panel_RegisterView.Size = new System.Drawing.Size(454, 360);
            this.panel_RegisterView.TabIndex = 22;
            this.panel_RegisterView.Visible = false;
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(312, 79);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(154, 44);
            this.btn_LogOut.TabIndex = 24;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // lbl_UCBank_MainView
            // 
            this.lbl_UCBank_MainView.AutoSize = true;
            this.lbl_UCBank_MainView.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_UCBank_MainView.Location = new System.Drawing.Point(95, 21);
            this.lbl_UCBank_MainView.Name = "lbl_UCBank_MainView";
            this.lbl_UCBank_MainView.Size = new System.Drawing.Size(224, 55);
            this.lbl_UCBank_MainView.TabIndex = 23;
            this.lbl_UCBank_MainView.Text = "UC Bank";
            // 
            // panel_MainView
            // 
            this.panel_MainView.Controls.Add(this.lbl_Rp);
            this.panel_MainView.Controls.Add(this.btn_Withdraw_MainView);
            this.panel_MainView.Controls.Add(this.btn_Deposit_MainView);
            this.panel_MainView.Controls.Add(this.lbl_Balance_MainView);
            this.panel_MainView.Controls.Add(this.btn_LogOut);
            this.panel_MainView.Controls.Add(this.lbl_UCBank_MainView);
            this.panel_MainView.Location = new System.Drawing.Point(86, 54);
            this.panel_MainView.Name = "panel_MainView";
            this.panel_MainView.Size = new System.Drawing.Size(637, 354);
            this.panel_MainView.TabIndex = 29;
            this.panel_MainView.Visible = false;
            this.panel_MainView.VisibleChanged += new System.EventHandler(this.panel_MainView_VisibleChanged);
            // 
            // btn_Deposit_DepositView
            // 
            this.btn_Deposit_DepositView.Location = new System.Drawing.Point(275, 129);
            this.btn_Deposit_DepositView.Name = "btn_Deposit_DepositView";
            this.btn_Deposit_DepositView.Size = new System.Drawing.Size(154, 44);
            this.btn_Deposit_DepositView.TabIndex = 33;
            this.btn_Deposit_DepositView.Text = "Deposit";
            this.btn_Deposit_DepositView.UseVisualStyleBackColor = true;
            this.btn_Deposit_DepositView.Click += new System.EventHandler(this.btn_Deposit_DepositView_Click);
            // 
            // lbl_InputDepositAmount
            // 
            this.lbl_InputDepositAmount.AutoSize = true;
            this.lbl_InputDepositAmount.Location = new System.Drawing.Point(237, 42);
            this.lbl_InputDepositAmount.Name = "lbl_InputDepositAmount";
            this.lbl_InputDepositAmount.Size = new System.Drawing.Size(223, 25);
            this.lbl_InputDepositAmount.TabIndex = 32;
            this.lbl_InputDepositAmount.Text = "Input Deposit Amount:";
            // 
            // panel_Deposit
            // 
            this.panel_Deposit.Controls.Add(this.tBox_JumlahDeposit);
            this.panel_Deposit.Controls.Add(this.btn_Deposit_DepositView);
            this.panel_Deposit.Controls.Add(this.lbl_InputDepositAmount);
            this.panel_Deposit.Location = new System.Drawing.Point(12, 189);
            this.panel_Deposit.Name = "panel_Deposit";
            this.panel_Deposit.Size = new System.Drawing.Size(682, 194);
            this.panel_Deposit.TabIndex = 36;
            this.panel_Deposit.Visible = false;
            // 
            // tBox_JumlahDeposit
            // 
            this.tBox_JumlahDeposit.Location = new System.Drawing.Point(242, 75);
            this.tBox_JumlahDeposit.Name = "tBox_JumlahDeposit";
            this.tBox_JumlahDeposit.Size = new System.Drawing.Size(213, 31);
            this.tBox_JumlahDeposit.TabIndex = 34;
            // 
            // tBox_JumlahWithdrawal
            // 
            this.tBox_JumlahWithdrawal.Location = new System.Drawing.Point(258, 102);
            this.tBox_JumlahWithdrawal.Name = "tBox_JumlahWithdrawal";
            this.tBox_JumlahWithdrawal.Size = new System.Drawing.Size(213, 31);
            this.tBox_JumlahWithdrawal.TabIndex = 39;
            // 
            // btn_Witdraw_WithdrawView
            // 
            this.btn_Witdraw_WithdrawView.Location = new System.Drawing.Point(291, 151);
            this.btn_Witdraw_WithdrawView.Name = "btn_Witdraw_WithdrawView";
            this.btn_Witdraw_WithdrawView.Size = new System.Drawing.Size(154, 44);
            this.btn_Witdraw_WithdrawView.TabIndex = 38;
            this.btn_Witdraw_WithdrawView.Text = "Withdraw";
            this.btn_Witdraw_WithdrawView.UseVisualStyleBackColor = true;
            this.btn_Witdraw_WithdrawView.Click += new System.EventHandler(this.btn_Witdraw_WithdrawView_Click);
            // 
            // lbl_InputWithdrawal
            // 
            this.lbl_InputWithdrawal.AutoSize = true;
            this.lbl_InputWithdrawal.Location = new System.Drawing.Point(238, 64);
            this.lbl_InputWithdrawal.Name = "lbl_InputWithdrawal";
            this.lbl_InputWithdrawal.Size = new System.Drawing.Size(256, 25);
            this.lbl_InputWithdrawal.TabIndex = 37;
            this.lbl_InputWithdrawal.Text = "Input Withdrawal Amount:";
            // 
            // lbl_Rupiah_WithdrawalView
            // 
            this.lbl_Rupiah_WithdrawalView.AutoSize = true;
            this.lbl_Rupiah_WithdrawalView.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Rupiah_WithdrawalView.Location = new System.Drawing.Point(333, 10);
            this.lbl_Rupiah_WithdrawalView.Name = "lbl_Rupiah_WithdrawalView";
            this.lbl_Rupiah_WithdrawalView.Size = new System.Drawing.Size(40, 42);
            this.lbl_Rupiah_WithdrawalView.TabIndex = 41;
            this.lbl_Rupiah_WithdrawalView.Text = "0";
            // 
            // lbl_Balance_WithdrawalView
            // 
            this.lbl_Balance_WithdrawalView.AutoSize = true;
            this.lbl_Balance_WithdrawalView.Location = new System.Drawing.Point(216, 27);
            this.lbl_Balance_WithdrawalView.Name = "lbl_Balance_WithdrawalView";
            this.lbl_Balance_WithdrawalView.Size = new System.Drawing.Size(90, 25);
            this.lbl_Balance_WithdrawalView.TabIndex = 40;
            this.lbl_Balance_WithdrawalView.Text = "Balance";
            // 
            // panel_WithdrawalView
            // 
            this.panel_WithdrawalView.Controls.Add(this.lbl_Rupiah_WithdrawalView);
            this.panel_WithdrawalView.Controls.Add(this.lbl_Balance_WithdrawalView);
            this.panel_WithdrawalView.Controls.Add(this.tBox_JumlahWithdrawal);
            this.panel_WithdrawalView.Controls.Add(this.btn_Witdraw_WithdrawView);
            this.panel_WithdrawalView.Controls.Add(this.lbl_InputWithdrawal);
            this.panel_WithdrawalView.Location = new System.Drawing.Point(12, 192);
            this.panel_WithdrawalView.Name = "panel_WithdrawalView";
            this.panel_WithdrawalView.Size = new System.Drawing.Size(685, 243);
            this.panel_WithdrawalView.TabIndex = 42;
            this.panel_WithdrawalView.Visible = false;
            // 
            // lbl_Rp
            // 
            this.lbl_Rp.AutoSize = true;
            this.lbl_Rp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Rp.Location = new System.Drawing.Point(225, 148);
            this.lbl_Rp.Name = "lbl_Rp";
            this.lbl_Rp.Size = new System.Drawing.Size(40, 42);
            this.lbl_Rp.TabIndex = 32;
            this.lbl_Rp.Text = "0";
            // 
            // btn_Withdraw_MainView
            // 
            this.btn_Withdraw_MainView.Location = new System.Drawing.Point(232, 278);
            this.btn_Withdraw_MainView.Name = "btn_Withdraw_MainView";
            this.btn_Withdraw_MainView.Size = new System.Drawing.Size(154, 44);
            this.btn_Withdraw_MainView.TabIndex = 31;
            this.btn_Withdraw_MainView.Text = "Withdraw";
            this.btn_Withdraw_MainView.UseVisualStyleBackColor = true;
            this.btn_Withdraw_MainView.Click += new System.EventHandler(this.btn_Withdraw_MainView_Click);
            // 
            // btn_Deposit_MainView
            // 
            this.btn_Deposit_MainView.Location = new System.Drawing.Point(232, 217);
            this.btn_Deposit_MainView.Name = "btn_Deposit_MainView";
            this.btn_Deposit_MainView.Size = new System.Drawing.Size(154, 44);
            this.btn_Deposit_MainView.TabIndex = 30;
            this.btn_Deposit_MainView.Text = "Deposit";
            this.btn_Deposit_MainView.UseVisualStyleBackColor = true;
            this.btn_Deposit_MainView.Click += new System.EventHandler(this.btn_Deposit_MainView_Click);
            // 
            // lbl_Balance_MainView
            // 
            this.lbl_Balance_MainView.AutoSize = true;
            this.lbl_Balance_MainView.Location = new System.Drawing.Point(129, 163);
            this.lbl_Balance_MainView.Name = "lbl_Balance_MainView";
            this.lbl_Balance_MainView.Size = new System.Drawing.Size(90, 25);
            this.lbl_Balance_MainView.TabIndex = 29;
            this.lbl_Balance_MainView.Text = "Balance";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 545);
            this.Controls.Add(this.panel_LoginView);
            this.Controls.Add(this.panel_RegisterView);
            this.Controls.Add(this.panel_Deposit);
            this.Controls.Add(this.panel_WithdrawalView);
            this.Controls.Add(this.panel_MainView);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_LoginView.ResumeLayout(false);
            this.panel_LoginView.PerformLayout();
            this.panel_RegisterView.ResumeLayout(false);
            this.panel_RegisterView.PerformLayout();
            this.panel_MainView.ResumeLayout(false);
            this.panel_MainView.PerformLayout();
            this.panel_Deposit.ResumeLayout(false);
            this.panel_Deposit.PerformLayout();
            this.panel_WithdrawalView.ResumeLayout(false);
            this.panel_WithdrawalView.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tBox_Username_LoginView;
        private System.Windows.Forms.TextBox tBox_Password_LoginView;
        private System.Windows.Forms.Label lbl_UCBank;
        private System.Windows.Forms.Label lbl_Username_LoginView;
        private System.Windows.Forms.Label lbl_Password_LoginView;
        private System.Windows.Forms.Button btn_Register_LoginView;
        private System.Windows.Forms.Button btn_Login_LoginView;
        private System.Windows.Forms.TextBox tBox_Password_RegisterView;
        private System.Windows.Forms.TextBox tBox_Username_RegisterView;
        private System.Windows.Forms.Button btn_Register_RegisterView;
        private System.Windows.Forms.Label lbl_Password_RegisterView;
        private System.Windows.Forms.Label lbl_Username_RegisterView;
        private System.Windows.Forms.Label lbl_UCBank_RegisterView;
        private System.Windows.Forms.Panel panel_LoginView;
        private System.Windows.Forms.Panel panel_RegisterView;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Label lbl_UCBank_MainView;
        private System.Windows.Forms.Panel panel_MainView;
        private System.Windows.Forms.Button btn_Deposit_DepositView;
        private System.Windows.Forms.Label lbl_InputDepositAmount;
        private System.Windows.Forms.Panel panel_Deposit;
        private System.Windows.Forms.TextBox tBox_JumlahDeposit;
        private System.Windows.Forms.TextBox tBox_JumlahWithdrawal;
        private System.Windows.Forms.Button btn_Witdraw_WithdrawView;
        private System.Windows.Forms.Label lbl_InputWithdrawal;
        private System.Windows.Forms.Label lbl_Rupiah_WithdrawalView;
        private System.Windows.Forms.Label lbl_Balance_WithdrawalView;
        private System.Windows.Forms.Panel panel_WithdrawalView;
        private System.Windows.Forms.Label lbl_Rp;
        private System.Windows.Forms.Button btn_Withdraw_MainView;
        private System.Windows.Forms.Button btn_Deposit_MainView;
        private System.Windows.Forms.Label lbl_Balance_MainView;
    }
}

